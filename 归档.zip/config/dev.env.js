module.exports = {
  NODE_ENV: '"development"',
  ENV_CONFIG: '"dev"',
//   BASE_API: '"https://api-dev"'
//   BASE_API: '"http://test.api.yuanlaihuyu.com"'
  BASE_API: '" https://easy-mock.com/mock/5b22112ce32fba5e118df6dc"'
//   BASE_API: '"http://localhost:9527"'
}
